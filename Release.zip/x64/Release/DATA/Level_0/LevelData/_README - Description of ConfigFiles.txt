TexturesData.conf

	Contains the filenames of the used textures.
	Need to be in the right order as used in "Map*Data".
	
	Format:

		One filename each line

	Example:
		Wall1.png
		Wall2.png
		Wall3.png
		Wall4.png 
		Floor1.png
		Ceiling1.png
		Crate1.png
		Console1.png
		Console2.png 
		Pipes1.png 
		Pipes2.png 
		Vent1.png 
		Vent2.png

