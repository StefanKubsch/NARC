Weapon_x_TexturesData.conf

	Contains the filenames of the used textures for each weapon.
		
	Format:

		One filename each line

	Example:

		./GFX/PlayerAssets/Weapons/ARX160/ARX160.png


_____________________________________


Weapon_x_MuzzleFlashTexturesData.conf

	Contains the filenames of the used muzzle flash texture for each weapon.
		
	Format:

		One filename each line

	Example:

		./GFX/PlayerAssets/Weapons/ARX160/MuzzleFlash.png